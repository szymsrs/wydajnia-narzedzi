# app/repo/reports_repo.py
from __future__ import annotations

from datetime import date, datetime
from typing import Iterable

import logging
from sqlalchemy import text
from sqlalchemy.engine import Engine

log = logging.getLogger(__name__)


class ReportsRepo:
    def __init__(self, engine: Engine):
        self.engine = engine
        self._ts_cache: dict[str, str | None] = {}  # view_name -> ts col or None

    # ---------- helpers ----------
    def _detect_ts_col(self, view_name: str, candidates: Iterable[str]) -> str | None:
        """
        Zwraca nazwę pierwszej istniejącej kolumny z `candidates` w widoku
        albo None, jeśli żadnej nie ma. Wynik jest cache'owany.
        """
        if view_name in self._ts_cache:
            return self._ts_cache[view_name]

        with self.engine.connect() as conn:
            cols = set(
                conn.execute(
                    text(
                        """
                        SELECT column_name
                        FROM information_schema.columns
                        WHERE table_schema = DATABASE() AND table_name = :t
                        """
                    ),
                    {"t": view_name},
                )
                .scalars()
                .all()
            )
        for c in candidates:
            if c in cols:
                self._ts_cache[view_name] = c
                return c
        self._ts_cache[view_name] = None
        return None

    # ---------- API ----------
    def rw_summary(
        self,
        date_from: datetime | date,
        date_to: datetime | date,
        limit: int = 500,
    ) -> list[dict]:
        sql = text(
            """
            SELECT *
            FROM vw_rw_summary
            WHERE rw_date >= :df
              AND rw_date <  :dt
            ORDER BY rw_date DESC, rw_id DESC
            LIMIT :lim
        """
        )
        with self.engine.connect() as conn:
            rows = (
                conn.execute(
                    sql,
                    {"df": date_from, "dt": date_to, "lim": int(limit)},
                )
                .mappings()
                .all()
            )
        return [dict(r) for r in rows]

    def exceptions(
        self,
        date_from: datetime | date,
        date_to: datetime | date,
        employee_id: int | None = None,
        item_id: int | None = None,
        limit: int = 500,
    ) -> list[dict]:
        """
        Zwraca listę wyjątków w podanym przedziale czasu, opcjonalnie
        filtrowaną po pracowniku i/lub narzędziu.
        """
        sql = text(
            """
            SELECT *
            FROM vw_exceptions
            WHERE created_at >= :df
              AND created_at <  :dt
              AND (:emp IS NULL OR employee_id = :emp)
              AND (:itm IS NULL OR item_id = :itm)
            ORDER BY created_at DESC
            LIMIT :lim
            """
        )
        params = {
            "df": date_from,
            "dt": date_to,
            "emp": employee_id,
            "itm": item_id,
            "lim": int(limit),
        }

        with self.engine.connect() as conn:
            rows = conn.execute(sql, params).mappings().all()
        return [dict(r) for r in rows]

    def employees(self, q: str = "", limit: int = 200) -> list[dict]:
        sql = text(
            """
            SELECT id, first_name, last_name, username AS login, rfid_uid
            FROM employees
            WHERE (
                :q = ''
                OR CONCAT_WS(' ', first_name, last_name, username)
                LIKE CONCAT('%', :q, '%')
            )
            ORDER BY last_name, first_name
            LIMIT :lim
        """
        )
        with self.engine.connect() as conn:
            rows = (
                conn.execute(
                    sql,
                    {"q": q or "", "lim": int(limit)},
                )
                .mappings()
                .all()
            )
        return [dict(r) for r in rows]

    def employee_card(self, employee_id: int, date_from: datetime | date, date_to: datetime | date) -> list[dict]:
        """Karta pracownika — filtruje po ``last_op``.

        Zwraca rekordy z widoku ``vw_employee_card`` dla wskazanego pracownika,
        których ``last_op`` mieści się w przedziale ``[date_from, date_to)``.
        """
        sql = text(
            """
            SELECT *
            FROM vw_employee_card
            WHERE employee_id = :emp
              AND last_op >= :df
              AND last_op <  :dt
            ORDER BY last_op DESC, item_id DESC
            """
        )
        params = {"emp": int(employee_id), "df": date_from, "dt": date_to}

        with self.engine.connect() as conn:
            rows = conn.execute(sql, params).mappings().all()
        return [dict(r) for r in rows]
