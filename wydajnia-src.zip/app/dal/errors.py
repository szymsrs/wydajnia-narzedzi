class NegativeStockError(RuntimeError):
    """Raised when an operation would result in negative stock."""
