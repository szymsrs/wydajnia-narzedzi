# Wydajnia narzędzi

## Instalacja

Aby przygotować środowisko developerskie uruchom:

```
pip install pre-commit && pre-commit install
```
